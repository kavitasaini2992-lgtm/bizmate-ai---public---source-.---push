// Server-side product catalogue.
// Prices live ONLY here — the browser never sends an amount to PayPal,
// it sends a productId and the server decides the price. This is what makes
// the checkout tamper-proof (a requirement of the project proposal:
// "Verifies payment status through the backend before confirming an order").

export const CURRENCY = 'USD';

export const products = [
  {
    id: 'business-guide-ebook',
    name: 'BizMate Premium Business Guide',
    tag: 'E-Book',
    price: 10,
    summary: 'A 60-page playbook covering pricing, listings, packaging and customer support for small online sellers.',
    features: ['Instant download', 'Lifetime updates', 'English + Hindi notes']
  },
  {
    id: 'social-template-pack',
    name: 'Social Media Template Pack',
    tag: 'Design kit',
    price: 18,
    summary: '30 editable product-promo templates for Instagram, WhatsApp status and Facebook marketplace.',
    features: ['30 templates', 'Canva + Figma files', 'Commercial licence']
  },
  {
    id: 'seller-starter-kit',
    name: 'Seller Starter Kit',
    tag: 'Bundle',
    price: 25,
    summary: 'Everything a new seller needs: the e-book, the template pack and a 20-point store audit checklist.',
    features: ['E-Book included', 'Template pack included', 'Audit checklist']
  }
];

export const findProduct = (id) => products.find((product) => product.id === id);

/** Format a number as a PayPal-compatible amount string ("10.00"). */
export const toAmount = (value) => Number(value).toFixed(2);
