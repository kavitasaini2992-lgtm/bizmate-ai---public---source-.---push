// Tiny JSON-file order store.
//
// A prototype-friendly replacement for an in-memory Map: orders survive a
// server restart, which matters when you demo the app and resend a receipt.
// For real production, swap this file for MongoDB/Postgres — the API
// (get / set / save) is intentionally the same shape.

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const FILE = path.join(__dirname, '..', 'data', 'orders.json');

const orders = new Map();

function load() {
  try {
    const raw = fs.readFileSync(FILE, 'utf8');
    const parsed = JSON.parse(raw);
    for (const order of parsed) {
      if (order?.orderId) orders.set(order.orderId, order);
    }
    console.log(`  Orders: loaded ${orders.size} saved order(s)`);
  } catch (error) {
    if (error.code !== 'ENOENT') {
      console.warn('  Orders: could not read orders.json — starting empty.', error.message);
    }
  }
}

function persist() {
  try {
    fs.mkdirSync(path.dirname(FILE), { recursive: true });
    fs.writeFileSync(FILE, JSON.stringify([...orders.values()], null, 2));
  } catch (error) {
    console.warn('  Orders: could not save orders.json.', error.message);
  }
}

load();

export const orderStore = {
  get: (orderId) => orders.get(orderId),
  set(orderId, order) {
    orders.set(orderId, order);
    persist();
    return order;
  },
  size: () => orders.size
};
