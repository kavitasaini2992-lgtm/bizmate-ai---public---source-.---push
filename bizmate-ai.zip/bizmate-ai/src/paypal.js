// PayPal Orders v2 (server-side) integration.
//
// The browser only ever receives the PUBLIC client id. Order creation and
// capture happen here, with the secret, so the price and the payment status
// cannot be faked from the frontend.

const ENV = (process.env.PAYPAL_ENV || 'sandbox').toLowerCase();
const API_BASE = ENV === 'live' ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com';

export const paypalConfigured = () =>
  Boolean(process.env.PAYPAL_CLIENT_ID && process.env.PAYPAL_CLIENT_SECRET);

export const paypalEnv = () => (ENV === 'live' ? 'live' : 'sandbox');

let cachedToken = null; // { value, expiresAt }

async function getAccessToken() {
  if (cachedToken && cachedToken.expiresAt > Date.now() + 30_000) {
    return cachedToken.value;
  }

  const credentials = Buffer.from(
    `${process.env.PAYPAL_CLIENT_ID}:${process.env.PAYPAL_CLIENT_SECRET}`
  ).toString('base64');

  const response = await fetch(`${API_BASE}/v1/oauth2/token`, {
    method: 'POST',
    headers: {
      Authorization: `Basic ${credentials}`,
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: 'grant_type=client_credentials',
    signal: AbortSignal.timeout(20_000)
  });

  if (!response.ok) {
    throw new PaypalError('Could not authenticate with PayPal. Check PAYPAL_CLIENT_ID / PAYPAL_CLIENT_SECRET.', response.status);
  }

  const data = await response.json();
  cachedToken = {
    value: data.access_token,
    expiresAt: Date.now() + (data.expires_in ?? 300) * 1000
  };
  return cachedToken.value;
}

export class PaypalError extends Error {
  constructor(message, status = 502, details = []) {
    super(message);
    this.name = 'PaypalError';
    this.status = status;
    this.details = details;
  }
}

async function paypalFetch(path, { method = 'GET', body } = {}) {
  const token = await getAccessToken();
  const response = await fetch(`${API_BASE}${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(20_000)
  });

  const text = await response.text();
  const data = text ? JSON.parse(text) : {};

  if (!response.ok) {
    const details = (data.details || []).map((item) => `${item.issue}: ${item.description}`);
    throw new PaypalError(data.message || `PayPal request failed (${response.status})`, response.status, details);
  }

  return data;
}

/** Create an order on PayPal's side for the given amount. */
export async function createPaypalOrder({ amount, currency, description, referenceId }) {
  return paypalFetch('/v2/checkout/orders', {
    method: 'POST',
    body: {
      intent: 'CAPTURE',
      purchase_units: [
        {
          reference_id: referenceId,
          description: description.slice(0, 127),
          amount: { currency_code: currency, value: amount }
        }
      ],
      application_context: {
        brand_name: 'BizMate AI',
        shipping_preference: 'NO_SHIPPING',
        user_action: 'PAY_NOW'
      }
    }
  });
}

/** Capture (take the money for) an approved order. */
export async function capturePaypalOrder(paypalOrderId) {
  return paypalFetch(`/v2/checkout/orders/${encodeURIComponent(paypalOrderId)}/capture`, {
    method: 'POST',
    body: {}
  });
}

/**
 * Verify a capture actually completed and for the expected amount.
 * This is the "payment verification" step of the project.
 */
export function verifyCapture(order, { expectedAmount, currency }) {
  const problems = [];

  if (order.status !== 'COMPLETED') {
    problems.push(`Order status is ${order.status}, expected COMPLETED.`);
  }

  const capture = order?.purchase_units?.[0]?.payments?.captures?.[0];
  if (!capture) {
    problems.push('No capture record found on the PayPal order.');
  } else {
    if (capture.status !== 'COMPLETED') {
      problems.push(`Capture status is ${capture.status}, expected COMPLETED.`);
    }
    if (capture.amount?.currency_code !== currency) {
      problems.push(`Currency mismatch: got ${capture.amount?.currency_code}, expected ${currency}.`);
    }
    if (Number(capture.amount?.value) !== Number(expectedAmount)) {
      problems.push(`Amount mismatch: got ${capture.amount?.value}, expected ${expectedAmount}.`);
    }
  }

  const payer = order?.payer ?? {};
  return {
    ok: problems.length === 0,
    problems,
    captureId: capture?.id ?? null,
    payerName: [payer.name?.given_name, payer.name?.surname].filter(Boolean).join(' ') || 'PayPal customer',
    payerEmail: payer.email_address ?? null
  };
}
