// AI helpers for BizMate AI.
//
// Works with any OpenAI-compatible Chat Completions endpoint. Configure via .env:
//   OPENAI_API_KEY  = your key            (required for real AI output)
//   AI_BASE_URL     = endpoint base url   (default: Freebuff paid API)
//   AI_MODEL        = model name          (default: gpt-4o-mini)
//
// If no key is configured the functions fall back to a small rule-based
// generator and mark the result with `demo: true`, so the app is still
// demoable and the UI can label the output honestly.

const BASE_URL = (process.env.AI_BASE_URL || 'https://freebuff.com/api/v1/paid').replace(/\/+$/, '');
const MODEL = process.env.AI_MODEL || 'gpt-4o-mini';
const TIMEOUT_MS = 25_000;

export const aiConfigured = () => Boolean(process.env.OPENAI_API_KEY);

async function chat(systemPrompt, userPrompt, maxTokens = 400) {
  const response = await fetch(`${BASE_URL}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`
    },
    body: JSON.stringify({
      model: MODEL,
      temperature: 0.7,
      max_tokens: maxTokens,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ]
    }),
    signal: AbortSignal.timeout(TIMEOUT_MS)
  });

  if (!response.ok) {
    const detail = await response.text().catch(() => '');
    throw new Error(`AI provider returned ${response.status}. ${detail.slice(0, 300)}`);
  }

  const data = await response.json();
  const text = data?.choices?.[0]?.message?.content?.trim();
  if (!text) throw new Error('AI provider returned an empty response.');
  return text;
}

/* ------------------------------------------------------------------ */
/* 1. Product description generator                                    */
/* ------------------------------------------------------------------ */

export async function generateDescription({ productName, productFeatures, tone = 'professional', audience = '' }) {
  if (!aiConfigured()) {
    return { text: demoDescription(productName, productFeatures), demo: true };
  }

  const system = [
    'You are BizMate AI, a copywriter for small online sellers in India.',
    'Write product descriptions that are clear, honest and sales-ready.',
    'Rules: no invented certifications, no fake discounts, no exaggerated health claims.',
    'Return plain text only (no markdown headings, no quotes around the whole answer).',
    'Structure: one short hook paragraph, then 3-5 bullet points starting with "- ", then a one line closing call to action.',
    'Keep it under 160 words.'
  ].join(' ');

  const user = [
    `Product name: ${productName}`,
    `Key features: ${productFeatures}`,
    `Tone: ${tone}`,
    audience ? `Target customer: ${audience}` : ''
  ].filter(Boolean).join('\n');

  return { text: await chat(system, user), demo: false };
}

/* ------------------------------------------------------------------ */
/* 2. Customer query assistant                                         */
/* ------------------------------------------------------------------ */

export async function draftReply({ customerQuery, businessName = 'our store', tone = 'polite' }) {
  if (!aiConfigured()) {
    return { text: demoReply(customerQuery, businessName), demo: true };
  }

  const system = [
    'You are BizMate AI, a customer support assistant for a small online business.',
    'Write a reply the seller can send as-is: greeting, clear answer, next step, sign-off.',
    'Never promise refunds, delivery dates or discounts that are not stated in the question.',
    'If information is missing, say what the seller should confirm before sending.',
    'Keep it under 130 words, plain text, no markdown.'
  ].join(' ');

  const user = [
    `Business name: ${businessName}`,
    `Tone: ${tone}`,
    `Customer message: ${customerQuery}`
  ].join('\n');

  return { text: await chat(system, user, 350), demo: false };
}

/* ------------------------------------------------------------------ */
/* Offline fallbacks (used only when no AI key is configured)          */
/* ------------------------------------------------------------------ */

function titleCase(value) {
  return value.replace(/\S+/g, (word) => word[0].toUpperCase() + word.slice(1));
}

function toPoints(features) {
  return features
    .split(/[,;\n•]+/)
    .map((item) => item.trim())
    .filter(Boolean)
    .slice(0, 5);
}

function demoDescription(productName, productFeatures) {
  const name = titleCase(productName.trim() || 'this product');
  const points = toPoints(productFeatures);
  const bullets = points.length
    ? points.map((point) => `- ${titleCase(point)}`).join('\n')
    : '- Thoughtfully designed for everyday use\n- Easy to order and ship';

  return [
    `Meet the ${name} — built for people who want something that simply works. Every detail is chosen to make daily use easier, so you spend less time fixing problems and more time getting on with your day.`,
    '',
    bullets,
    '',
    `Order the ${name} today and get it delivered straight to your doorstep.`
  ].join('\n');
}

function demoReply(customerQuery, businessName) {
  const query = customerQuery.trim();
  const lower = query.toLowerCase();

  let answer = 'Thanks for reaching out — I want to make sure I give you the right answer. Could you share your order ID so I can look into this for you?';

  if (/(refund|return|money back)/.test(lower)) {
    answer = 'Thanks for writing in. Refunds are processed within 5-7 working days after we receive the returned item. Please share your order ID and I will start the request for you right away.';
  } else if (/(ship|deliver|courier|track)/.test(lower)) {
    answer = 'Thanks for your message. Once your order is dispatched you will receive a tracking link by email, and most orders arrive within 3-5 working days. If you share your order ID I will check the current status for you.';
  } else if (/(payment|paypal|pay|failed)/.test(lower)) {
    answer = 'Thanks for reaching out. If a payment failed, no money leaves your account until the transaction completes successfully. Please share the transaction reference and I will verify it on our side.';
  } else if (/(price|discount|offer|bulk)/.test(lower)) {
    answer = 'Thanks for your interest. We do have special pricing for bulk orders. Let me know the quantity you need and I will send you a quote with the best possible rate.';
  }

  return [
    `Hello,`,
    '',
    answer,
    '',
    `Warm regards,`,
    `Customer Support — ${businessName}`
  ].join('\n');
}
