# BizMate AI — Testing Video Script

Ek 3–4 minute ka screen-recording script, shot-by-shot. Aap sirf record karo, bolne ki line
neeche likhi hai. Ye "testing video" hai — isliye har shot mein **proof** dikhna chahiye,
sirf UI ghumana nahi.

---

## Recording se pehle (5 minute)

**Ready hona chahiye:**

- [ ] `node -v` chalta hai (v20+)
- [ ] `npm install` ho chuka hai
- [ ] `.env` mein `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET` (sandbox) + `OPENAI_API_KEY`
- [ ] Sandbox **Personal** account ka email/password haath mein (developer.paypal.com →
      Testing Tools → Sandbox Accounts)
- [ ] Terminal font 16–18pt, browser zoom 100%, window ~1280×800
- [ ] Notifications off (Windows: Focus assist), WhatsApp/Telegram band
- [ ] Ek dry run pehle kar lo — ab orders `data/orders.json` mein save hote hain, isliye
      restart se demo kharab nahi hoga

**Recording tool (free):**

| Tool | Kaise |
| --- | --- |
| OBS Studio | `obsproject.com` → Scene: Display Capture → Settings → Output 1080p 30fps |
| Xbox Game Bar | `Win + G` → record button (quick, no install) |

Mic test pehle kar lo — 10 second record karke sun lo. Awaaz dheemi ho to system volume
badhao, baad mein fix nahi hota.

---

## Shot list

### Shot 1 · Intro (0:00 – 0:15)

**Screen:** Title slide ya README kholo.
**Bolo:**
> "Ye BizMate AI hai — chhote online sellers ke liye AI business assistant. Is video mein
> main teen cheezein test karunga: AI description generator, customer query assistant, aur
> PayPal Sandbox payment jo server pe verify hoti hai."

### Shot 2 · Setup proof (0:15 – 0:45)

**Screen:** Terminal.
**Karo:**

```bash
node -v
npm install
npm start
```

**Bolo (startup banner pe point karo):**
> "Dekhiye banner: AI live hai aur PayPal SANDBOX environment pe hai. Matlab ye dummy
> frontend nahi hai — dono integrations configured hain."

### Shot 3 · AI description (0:45 – 1:15)

**Screen:** Browser → `http://localhost:3000`.

**Karo:** Product name: `Handwoven Jute Tote Bag` · Features:
`handmade in Kolkata, eco-friendly jute, fits a laptop, cotton lining, free shipping in India`
→ **Generate description**.

**Bolo:**
> "Ye request server pe jaati hai, API key browser mein nahi hai. Output aata hai — aur main
> ise copy karke seedha listing mein paste kar sakta hoon."

> **Tip:** DevTools → Network tab khol ke `ai/description` request dikhao. Ye proof hai ki
> key frontend mein nahi hai.

### Shot 4 · Customer query assistant (1:15 – 1:40)

**Karo:** Customer message: `Mera refund kab tak aayega? Order 3 din pehle return kiya tha.`
· Business name: `Asha Handlooms` → **Draft reply**.

**Bolo:**
> "Buyer ka sawaal paste karo, polite reply mil jaata hai. Chhote sellers ke liye sabse bada
> time-saver yahi hai."

### Shot 5 · PayPal Sandbox payment (1:40 – 2:40) ⭐ sabse important

**Karo:**

1. Catalogue mein **Seller Starter Kit ($25)** → **Buy now**
2. Checkout card dikhao — bolo: *"price server se aa raha hai, browser se nahi."*
3. **PayPal button** click karo
4. PayPal sandbox login → **Sandbox Personal** account
5. **Pay Now** → wapas app pe redirect
6. Receipt dikhao — **zoom karo** order ID, capture ID, status `COMPLETED`, amount pe

**Bolo:**
> "Order server pe banti hai secret key se, browser ke paas sirf public client ID hai. Payment
> ke baad server PayPal se capture karta hai aur **status, amount aur currency verify** karta
> hai — tabhi order confirmed hota hai. Paisa nahi kata, ye sandbox hai."

### Shot 6 · Security proof (2:40 – 3:10) ⭐ judges ko yahi impress karta hai

**Screen:** Naya terminal tab.

```bash
curl -s -X POST localhost:3000/api/orders -H "Content-Type: application/json" \
  -d '{"productId":"business-guide-ebook","amount":"0.01"}'
```

**Bolo (output pe point karo):**
> "Maine client se 0.01 bheja — server ne 10.00 charge kiya. Kyunki price server-side
> catalogue se aati hai. Isi tarah capture sirf tab accept hota hai jab PayPal `COMPLETED`
> bole aur amount match kare."

### Shot 7 · Persistence proof (3:10 – 3:25)

**Screen:** Terminal — server restart karo, phir purana order maango.

```bash
# Ctrl+C to stop, then:
npm start
```

Dusre tab mein (apna order ID daalo):

```bash
curl -s localhost:3000/api/orders/BM-XXXXXXXX-XXXX
```

**Bolo:**
> "Server restart ke baad bhi order `COMPLETED` hai — orders `data/orders.json` mein persist
> hote hain, memory mein nahi."

### Shot 8 · Honest close (3:25 – 3:35)

**Bolo:**
> "Jo abhi nahi hai: real database, user accounts, aur live PayPal — wo business account aur
> KYC ke baad hota hai. Sandbox mein poora payment flow end-to-end verified hai."

---

## Optional shot · CLI credit (3:35 – 4:00)

Agar sirf PayPal integration dikhana ho (bina UI ke):

```bash
node scripts/paypal-check.js
```

Approval link kholo → **Pay Now** → phir:

```bash
node scripts/paypal-check.js capture <paypalOrderId>
```

`Verification : PASSED` line pe zoom karo. Ye direct proof hai ki OAuth, order creation,
capture aur amount verification — sab PayPal ki asli sandbox API ke against kaam karte hain.

---

## Agar sandbox keys abhi nahi hain

Video ko do parts mein record karo:

1. **Part A (abhi):** Shot 1–4 + "Simulate sandbox payment" wala demo checkout (UI clearly
   "Demo mode" likhta hai — ise chhupao mat).
2. **Part B (keys aane ke baad):** Shot 5 + 6 + optional CLI, aur part A ke aage jod do.

Judges ke saamne demo mode ko real payment batana sabse bada risk hai — clear bolna hi
credibility deta hai.

---

## Editing (10 minute, CapCut ya Clipchamp)

- Shuru ka 1–2 second aur PayPal login ka wait **cut** kar do
- Receipt aur `Verification : PASSED` pe **zoom-in** + 2 second hold
- Har shot pe chhota caption: `AI Description` · `Query Assistant` · `PayPal Sandbox` ·
  `Server-side verification`
- Thumbnail ke liye `artifacts/01-ai-writer.png` ya `artifacts/03-receipt.png` use karo
- Export 1080p MP4, file name `bizmate-ai-testing.mp4`

---

## Practice lines (ek hi saans mein)

> "Ye BizMate AI hai. AI live hai, PayPal sandbox pe hai. Description generate hoti hai
> server-side API se. Query ka reply draft hota hai. Payment server pe banti hai — price
> browser se nahi aati. Payment ke baad server status aur amount verify karta hai, tabhi
> order confirm hota hai. Server restart ke baad bhi order save rehta hai."

Bas. 3 minute 30 second.
