// PayPal Sandbox diagnostic — proves the server-side integration really works.
//
//   node scripts/paypal-check.js            -> create a sandbox order, print the approval link
//   node scripts/paypal-check.js capture ID -> capture + verify that order
//
// Uses the same src/paypal.js the server uses, so a pass here means the
// credentials, OAuth, order creation, capture and verification all work.

import 'dotenv/config';

const Paypal = await import('../src/paypal.js');
const { findProduct } = await import('../data/products.js');

const mask = (value) => (value ? `${value.slice(0, 6)}…(${value.length} chars)` : 'NOT SET');

console.log('PayPal environment :', Paypal.paypalEnv());
console.log('Client ID          :', mask(process.env.PAYPAL_CLIENT_ID));
console.log('Client secret      :', process.env.PAYPAL_CLIENT_SECRET ? 'SET (hidden)' : 'NOT SET');

if (!Paypal.paypalConfigured()) {
  console.error('\nPAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET must both be set in .env');
  process.exit(1);
}

const [mode, orderIdArg] = process.argv.slice(2);

try {
  if (mode === 'capture') {
    if (!orderIdArg) {
      console.error('Usage: node scripts/paypal-check.js capture <paypalOrderId>');
      process.exit(1);
    }

    console.log('\nCapturing', orderIdArg, '…');
    const order = await Paypal.capturePaypalOrder(orderIdArg);
    const amount = order?.purchase_units?.[0]?.payments?.captures?.[0]?.amount?.value;

    console.log('Order status       :', order.status);
    console.log('Captured amount    :', amount ? `${amount} ${order.purchase_units[0].payments.captures[0].amount.currency_code}` : '—');
    console.log('Payer              :', order?.payer?.email_address || '—');

    const check = Paypal.verifyCapture(order, {
      expectedAmount: amount,
      currency: order?.purchase_units?.[0]?.payments?.captures?.[0]?.amount?.currency_code || 'USD'
    });

    console.log('Verification       :', check.ok ? 'PASSED' : 'FAILED');
    if (!check.ok) console.log('Problems           :', check.problems);
    console.log('Capture ID         :', check.captureId);
    process.exit(check.ok ? 0 : 2);
  }

  const product = findProduct('business-guide-ebook');
  const amount = product.price.toFixed(2);

  console.log(`\nCreating a ${amount} ${product.currency} sandbox order for "${product.name}" …`);
  const order = await Paypal.createPaypalOrder({
    amount,
    currency: product.currency,
    description: product.name,
    referenceId: `CHECK-${Date.now()}`
  });

  const approve = (order.links || []).find((link) => link.rel === 'approve' || link.rel === 'payer-action');

  console.log('PayPal order ID    :', order.id);
  console.log('Order status       :', order.status);

  if (!approve) {
    console.log('\nNo approval link returned. Full response:');
    console.log(JSON.stringify(order, null, 2));
    process.exit(1);
  }

  console.log('\n1) Open this link and log in with a SANDBOX PERSONAL account');
  console.log('   (developer.paypal.com -> Testing Tools -> Sandbox Accounts):\n');
  console.log('   ' + approve.href);
  console.log('\n2) Click "Pay Now" (fake money, nothing is charged).');
  console.log('3) Then run:\n');
  console.log(`   node scripts/paypal-check.js capture ${order.id}\n`);
} catch (error) {
  console.error('\nFAILED:', error.message);
  if (error.details?.length) console.error('Details:', error.details);
  console.error('HTTP status:', error.status ?? '(none)');
  process.exit(1);
}
