/* BizMate AI — frontend logic */

const state = {
  products: [],
  currency: 'USD',
  paypal: { clientId: null, mode: 'demo' },
  sdkLoading: null,
  buttons: null,
  product: null,
  order: null
};

const $ = (id) => document.getElementById(id);

/* --------------------------- small helpers --------------------------- */

async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: { 'Content-Type': 'application/json' },
    ...options
  });

  let data = {};
  try {
    data = await response.json();
  } catch {
    /* empty body */
  }

  if (!response.ok) {
    const error = new Error(data.error || `Request failed (${response.status})`);
    error.payload = data;
    throw error;
  }
  return data;
}

const money = (amount, currency = state.currency) => {
  try {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency }).format(Number(amount));
  } catch {
    return `${currency} ${Number(amount).toFixed(2)}`;
  }
};

function setStatus(element, message, kind = '') {
  element.textContent = message || '';
  element.className = `status${kind ? ` is-${kind}` : ''}`;
}

function setBusy(button, busy, busyLabel = 'Working…') {
  if (busy) {
    button.dataset.label = button.textContent;
    button.textContent = busyLabel;
    button.disabled = true;
  } else {
    button.textContent = button.dataset.label || button.textContent;
    button.disabled = false;
  }
}

/* ----------------------------- catalogue ----------------------------- */

async function loadCatalogue() {
  const grid = $('productGrid');

  try {
    const data = await api('/api/catalog');
    state.products = data.products;
    state.currency = data.currency;

    grid.innerHTML = '';
    for (const product of data.products) {
      const card = document.createElement('article');
      card.className = 'product';

      const tag = document.createElement('span');
      tag.className = 'product__tag';
      tag.textContent = product.tag;

      const title = document.createElement('h3');
      title.textContent = product.name;

      const summary = document.createElement('p');
      summary.textContent = product.summary;

      const list = document.createElement('ul');
      for (const feature of product.features) {
        const li = document.createElement('li');
        li.textContent = feature;
        list.appendChild(li);
      }

      const foot = document.createElement('div');
      foot.className = 'product__foot';

      const price = document.createElement('span');
      price.className = 'product__price';
      price.innerHTML = `${money(product.price)} <small>${state.currency}</small>`;

      const buy = document.createElement('button');
      buy.className = 'btn btn--primary';
      buy.type = 'button';
      buy.textContent = 'Buy now';
      buy.addEventListener('click', () => startCheckout(product));

      foot.append(price, buy);
      card.append(tag, title, summary, list, foot);
      grid.appendChild(card);
    }
  } catch (error) {
    grid.innerHTML = '';
    const message = document.createElement('p');
    message.className = 'status is-error';
    message.textContent = `Could not load products: ${error.message}`;
    grid.appendChild(message);
  }
}

/* ------------------------------- pills ------------------------------- */

async function loadHealth() {
  try {
    const health = await api('/api/health');

    const aiPill = $('pill-ai');
    const aiLive = health.ai === 'configured';
    aiPill.textContent = aiLive ? 'AI: live' : 'AI: demo mode';
    aiPill.classList.add(aiLive ? 'is-live' : 'is-demo');

    const ppPill = $('pill-paypal');
    const ppLive = health.paypal !== 'demo';
    ppPill.textContent = ppLive ? `PayPal: ${health.paypal}` : 'PayPal: demo mode';
    ppPill.classList.add(ppLive ? 'is-live' : 'is-demo');
  } catch {
    $('pill-ai').textContent = 'AI: offline';
    $('pill-paypal').textContent = 'PayPal: offline';
  }
}

/* --------------------------- AI: description -------------------------- */

function initDescriptionForm() {
  const form = $('description-form');
  const button = form.querySelector('button[type="submit"]');
  const status = $('descStatus');

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const productName = $('prodName').value.trim();
    const productFeatures = $('prodFeatures').value.trim();

    if (!productName || !productFeatures) {
      setStatus(status, 'Please fill in the product name and at least one feature.', 'error');
      return;
    }

    setBusy(button, true, 'Writing…');
    setStatus(status, 'Generating your description…', 'busy');

    try {
      const data = await api('/api/ai/description', {
        method: 'POST',
        body: JSON.stringify({
          productName,
          productFeatures,
          tone: $('prodTone').value,
          audience: $('prodAudience').value.trim()
        })
      });

      $('descText').textContent = data.description;
      $('descOutput').hidden = false;

      const badge = $('descBadge');
      badge.textContent = data.demo ? 'Demo output — add AI key' : 'AI output';
      badge.classList.toggle('is-demo', Boolean(data.demo));

      setStatus(status, data.demo
        ? 'Offline demo output. Add OPENAI_API_KEY to .env for real AI writing.'
        : 'Done. Copy it into your listing.');
    } catch (error) {
      setStatus(status, error.message, 'error');
    } finally {
      setBusy(button, false);
    }
  });
}

/* ----------------------------- AI: reply ----------------------------- */

function initReplyForm() {
  const form = $('reply-form');
  const button = form.querySelector('button[type="submit"]');
  const status = $('replyStatus');

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const customerQuery = $('custQuery').value.trim();

    if (!customerQuery) {
      setStatus(status, 'Please paste the customer question first.', 'error');
      return;
    }

    setBusy(button, true, 'Drafting…');
    setStatus(status, 'Drafting a reply…', 'busy');

    try {
      const data = await api('/api/ai/reply', {
        method: 'POST',
        body: JSON.stringify({
          customerQuery,
          businessName: $('businessName').value.trim(),
          tone: $('replyTone').value
        })
      });

      $('replyText').textContent = data.reply;
      $('replyOutput').hidden = false;

      const badge = $('replyBadge');
      badge.textContent = data.demo ? 'Demo output — add AI key' : 'AI output';
      badge.classList.toggle('is-demo', Boolean(data.demo));

      setStatus(status, data.demo
        ? 'Offline demo reply. Add OPENAI_API_KEY to .env for real AI drafting.'
        : 'Done. Read it once before sending.');
    } catch (error) {
      setStatus(status, error.message, 'error');
    } finally {
      setBusy(button, false);
    }
  });
}

/* ------------------------------ PayPal ------------------------------- */

async function loadPaypalConfig() {
  try {
    state.paypal = await api('/api/paypal/config');
  } catch {
    state.paypal = { clientId: null, mode: 'demo' };
  }
  return state.paypal;
}

function loadPaypalSdk() {
  if (window.paypal) return Promise.resolve();
  if (state.sdkLoading) return state.sdkLoading;

  const { clientId } = state.paypal;
  if (!clientId) return Promise.reject(new Error('No PayPal client id configured.'));

  state.sdkLoading = new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = `https://www.paypal.com/sdk/js?client-id=${encodeURIComponent(clientId)}&currency=${encodeURIComponent(state.currency)}&intent=capture&components=buttons`;
    script.async = true;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error('Could not load the PayPal SDK. Check your internet connection.'));
    document.head.appendChild(script);
  });

  return state.sdkLoading;
}

function closePaypalButtons() {
  if (state.buttons) {
    try {
      state.buttons.close();
    } catch {
      /* SDK may already be torn down */
    }
    state.buttons = null;
  }
  $('paypal-buttons').innerHTML = '';
}

async function startCheckout(product) {
  state.product = product;
  state.order = null;

  $('receipt').hidden = true;
  $('checkout').hidden = false;
  $('checkoutTitle').textContent = product.name;
  $('checkoutDesc').textContent = product.summary;
  $('checkoutPrice').textContent = money(product.price);
  setStatus($('payStatus'), '');

  closePaypalButtons();

  const config = await loadPaypalConfig();
  const demoButton = $('demoPayBtn');
  const slot = $('paypal-buttons');

  if (config.mode === 'demo') {
    slot.hidden = true;
    demoButton.hidden = false;
    $('checkoutMode').textContent =
      'Demo mode: PayPal Sandbox keys are not configured, so the payment is simulated locally. Add PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET to .env to run the real sandbox checkout.';
  } else {
    demoButton.hidden = true;
    slot.hidden = false;
    $('checkoutMode').textContent =
      `PayPal ${config.mode} environment. You will be redirected to PayPal to approve a test payment — no real money moves.`;

    try {
      await loadPaypalSdk();
      renderPaypalButtons(product);
    } catch (error) {
      setStatus($('payStatus'), error.message, 'error');
    }
  }

  $('checkout').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function renderPaypalButtons(product) {
  const container = $('paypal-buttons');
  container.innerHTML = '';
  const status = $('payStatus');

  state.buttons = window.paypal.Buttons({
    style: { shape: 'rect', color: 'blue', layout: 'vertical', label: 'paypal', height: 45 },

    createOrder: async () => {
      setStatus(status, 'Creating a secure order on the server…', 'busy');
      const order = await api('/api/orders', {
        method: 'POST',
        body: JSON.stringify({ productId: product.id, quantity: 1 })
      });
      state.order = order;
      return order.paypalOrderId;
    },

    onApprove: async (data) => {
      setStatus(status, 'Payment approved. Verifying with PayPal…', 'busy');

      const orderId = state.order?.orderId;
      if (!orderId) {
        setStatus(status, 'Order reference lost. Please reload and try again.', 'error');
        return;
      }

      try {
        const receipt = await api(`/api/orders/${encodeURIComponent(orderId)}/capture`, { method: 'POST' });
        showReceipt(receipt);
      } catch (error) {
        setStatus(status, error.message, 'error');
        if (error.payload?.problems?.length) {
          console.warn('Verification problems:', error.payload.problems);
        }
      }
    },

    onCancel: () => setStatus(status, 'Checkout cancelled. Nothing was charged.'),
    onError: (error) => {
      console.error(error);
      setStatus(status, 'PayPal checkout failed. Please try again.', 'error');
    }
  });

  state.buttons.render(container).catch((error) => {
    console.error(error);
    setStatus(status, 'Could not render the PayPal buttons.', 'error');
  });
}

function initDemoPayment() {
  $('demoPayBtn').addEventListener('click', async (event) => {
    const button = event.currentTarget;
    const status = $('payStatus');
    const product = state.product;
    if (!product) return;

    setBusy(button, true, 'Processing…');
    setStatus(status, 'Creating a demo order and verifying payment…', 'busy');

    try {
      const order = await api('/api/orders', {
        method: 'POST',
        body: JSON.stringify({ productId: product.id, quantity: 1 })
      });
      const receipt = await api(`/api/orders/${encodeURIComponent(order.orderId)}/capture`, { method: 'POST' });
      setStatus(status, '');
      showReceipt(receipt);
    } catch (error) {
      setStatus(status, error.message, 'error');
    } finally {
      setBusy(button, false);
    }
  });
}

/* ------------------------------ receipt ------------------------------ */

function showReceipt(order) {
  const rows = [
    ['Order ID', order.orderId],
    ['Product', `${order.productName} × ${order.quantity}`],
    ['Amount', money(order.amount, order.currency)],
    ['Payment status', order.status],
    ['PayPal order', order.paypalOrderId],
    ['Capture ID', order.captureId || '—'],
    ['Payer', order.payerName ? `${order.payerName}${order.payerEmail ? ` (${order.payerEmail})` : ''}` : '—'],
    ['Paid at', order.paidAt ? new Date(order.paidAt).toLocaleString() : '—']
  ];

  const list = $('receiptRows');
  list.innerHTML = '';

  for (const [label, value] of rows) {
    const row = document.createElement('div');
    row.className = 'receipt__row';

    const dt = document.createElement('dt');
    dt.textContent = label;

    const dd = document.createElement('dd');
    dd.textContent = value;

    row.append(dt, dd);
    list.appendChild(row);
  }

  $('receiptTitle').textContent = 'Order confirmed';
  $('receiptSub').textContent = order.mode === 'demo'
    ? 'Demo payment verified on the server. No real money was charged.'
    : 'Payment verified by the backend with PayPal and the order was confirmed.';

  $('checkout').hidden = true;
  $('receipt').hidden = false;
  $('receipt').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/* ------------------------------ wiring ------------------------------- */

function initCopyButtons() {
  for (const button of document.querySelectorAll('[data-copy]')) {
    button.addEventListener('click', async () => {
      const text = $(button.dataset.copy).textContent;
      try {
        await navigator.clipboard.writeText(text);
        button.textContent = 'Copied';
        setTimeout(() => { button.textContent = 'Copy'; }, 1500);
      } catch {
        button.textContent = 'Press Ctrl+C';
        setTimeout(() => { button.textContent = 'Copy'; }, 2000);
      }
    });
  }
}

function initCheckoutControls() {
  const chooseAnother = () => {
    closePaypalButtons();
    $('checkout').hidden = true;
    state.product = null;
    state.order = null;
    document.getElementById('catalogue').scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  $('cancelCheckout').addEventListener('click', chooseAnother);

  $('newOrderBtn').addEventListener('click', () => {
    $('receipt').hidden = true;
    chooseAnother();
  });
}

async function init() {
  initDescriptionForm();
  initReplyForm();
  initDemoPayment();
  initCopyButtons();
  initCheckoutControls();

  await Promise.all([loadHealth(), loadCatalogue()]);
  await loadPaypalConfig();
}

init();
