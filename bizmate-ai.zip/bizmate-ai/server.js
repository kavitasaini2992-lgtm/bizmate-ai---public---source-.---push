import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

import { products, findProduct, CURRENCY, toAmount } from './data/products.js';
import { generateDescription, draftReply, aiConfigured } from './src/ai.js';
import {
  paypalConfigured,
  paypalEnv,
  createPaypalOrder,
  capturePaypalOrder,
  verifyCapture,
  PaypalError
} from './src/paypal.js';
import { orderStore as orders } from './src/orderStore.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.disable('x-powered-by');
app.use(express.json({ limit: '100kb' }));
app.use(express.static(path.join(__dirname, 'public')));

/* ------------------------------------------------------------------ */
/* Order store — persisted to data/orders.json so restarts keep orders */
/* ------------------------------------------------------------------ */

const newOrderId = () => `BM-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(2).toString('hex').toUpperCase()}`;

const publicOrder = (order) => ({
  orderId: order.orderId,
  productId: order.productId,
  productName: order.productName,
  quantity: order.quantity,
  amount: order.amount,
  currency: order.currency,
  status: order.status,
  mode: order.mode,
  paypalOrderId: order.paypalOrderId,
  captureId: order.captureId ?? null,
  payerName: order.payerName ?? null,
  payerEmail: order.payerEmail ?? null,
  createdAt: order.createdAt,
  paidAt: order.paidAt ?? null
});

/* ------------------------------------------------------------------ */
/* Very small per-IP rate limiter for the AI routes                    */
/* (they spend the owner's API credits, so they are not unlimited)     */
/* ------------------------------------------------------------------ */

const AI_LIMIT = Number(process.env.AI_REQUESTS_PER_10_MIN) || 20;
const AI_WINDOW_MS = 10 * 60 * 1000;
const aiHits = new Map(); // ip -> timestamps[]

function aiRateLimit(req, res, next) {
  const now = Date.now();
  const key = req.ip || 'unknown';
  const hits = (aiHits.get(key) || []).filter((time) => now - time < AI_WINDOW_MS);

  if (hits.length >= AI_LIMIT) {
    return res.status(429).json({
      error: `Too many AI requests. Please wait a few minutes (limit: ${AI_LIMIT} per 10 minutes).`
    });
  }

  hits.push(now);
  aiHits.set(key, hits);
  next();
}

/* ------------------------------------------------------------------ */
/* Routes                                                              */
/* ------------------------------------------------------------------ */

app.get('/api/health', (req, res) => {
  res.json({
    ok: true,
    ai: aiConfigured() ? 'configured' : 'demo',
    paypal: paypalConfigured() ? paypalEnv() : 'demo'
  });
});

app.get('/api/catalog', (req, res) => {
  res.json({
    currency: CURRENCY,
    products,
    paypalConfigured: paypalConfigured(),
    aiConfigured: aiConfigured()
  });
});

/** Public config for the browser — never expose the secret. */
app.get('/api/paypal/config', (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json({
    clientId: paypalConfigured() ? process.env.PAYPAL_CLIENT_ID : null,
    currency: CURRENCY,
    mode: paypalConfigured() ? paypalEnv() : 'demo'
  });
});

app.post('/api/ai/description', aiRateLimit, async (req, res, next) => {
  try {
    const { productName, productFeatures, tone, audience } = req.body ?? {};

    if (!productName?.trim() || !productFeatures?.trim()) {
      return res.status(400).json({ error: 'Product name and features are both required.' });
    }
    if (productName.length > 120 || productFeatures.length > 800) {
      return res.status(400).json({ error: 'Input is too long. Keep name under 120 and features under 800 characters.' });
    }

    const result = await generateDescription({
      productName: productName.trim(),
      productFeatures: productFeatures.trim(),
      tone: typeof tone === 'string' ? tone.slice(0, 30) : 'professional',
      audience: typeof audience === 'string' ? audience.slice(0, 120) : ''
    });

    res.json({ description: result.text, demo: result.demo });
  } catch (error) {
    next(error);
  }
});

app.post('/api/ai/reply', aiRateLimit, async (req, res, next) => {
  try {
    const { customerQuery, businessName, tone } = req.body ?? {};

    if (!customerQuery?.trim()) {
      return res.status(400).json({ error: 'Please enter the customer question.' });
    }
    if (customerQuery.length > 800) {
      return res.status(400).json({ error: 'Question is too long. Keep it under 800 characters.' });
    }

    const result = await draftReply({
      customerQuery: customerQuery.trim(),
      businessName: typeof businessName === 'string' && businessName.trim() ? businessName.trim().slice(0, 60) : 'our store',
      tone: typeof tone === 'string' ? tone.slice(0, 30) : 'polite'
    });

    res.json({ reply: result.text, demo: result.demo });
  } catch (error) {
    next(error);
  }
});

/** Create an order. Price always comes from the server-side catalogue. */
app.post('/api/orders', async (req, res, next) => {
  try {
    const { productId, quantity } = req.body ?? {};
    const product = findProduct(productId);

    if (!product) {
      return res.status(400).json({ error: 'Unknown product. Please pick an item from the catalogue.' });
    }

    const qty = Math.min(Math.max(Number.parseInt(quantity ?? 1, 10) || 1, 1), 10);
    const amount = toAmount(product.price * qty);
    const orderId = newOrderId();

    if (!paypalConfigured()) {
      const order = {
        orderId,
        productId: product.id,
        productName: product.name,
        quantity: qty,
        amount,
        currency: CURRENCY,
        status: 'CREATED',
        mode: 'demo',
        paypalOrderId: `DEMO-${orderId}`,
        createdAt: new Date().toISOString()
      };
      orders.set(orderId, order);
      return res.status(201).json({ ...publicOrder(order), demo: true });
    }

    const created = await createPaypalOrder({
      amount,
      currency: CURRENCY,
      description: product.name,
      referenceId: product.id
    });

    const order = {
      orderId,
      productId: product.id,
      productName: product.name,
      quantity: qty,
      amount,
      currency: CURRENCY,
      status: 'CREATED',
      mode: paypalEnv(),
      paypalOrderId: created.id,
      createdAt: new Date().toISOString()
    };
    orders.set(orderId, order);

    res.status(201).json(publicOrder(order));
  } catch (error) {
    next(error);
  }
});

/** Capture + verify a payment before confirming the order. */
app.post('/api/orders/:orderId/capture', async (req, res, next) => {
  try {
    const order = orders.get(req.params.orderId);
    if (!order) {
      return res.status(404).json({ error: 'Order not found.' });
    }
    if (order.status === 'COMPLETED') {
      return res.json({ ...publicOrder(order), alreadyCaptured: true });
    }

    if (order.mode === 'demo') {
      order.status = 'COMPLETED';
      order.captureId = `DEMO-CAPTURE-${order.orderId}`;
      order.payerName = 'Demo Customer';
      order.payerEmail = 'demo-buyer@example.com';
      order.paidAt = new Date().toISOString();
      orders.set(order.orderId, order);
      return res.json({ ...publicOrder(order), demo: true });
    }

    const captured = await capturePaypalOrder(order.paypalOrderId);
    const verification = verifyCapture(captured, {
      expectedAmount: order.amount,
      currency: order.currency
    });

    if (!verification.ok) {
      order.status = 'VERIFICATION_FAILED';
      order.verificationProblems = verification.problems;
      orders.set(order.orderId, order);
      return res.status(402).json({
        error: 'Payment could not be verified, so the order was not confirmed.',
        problems: verification.problems,
        order: publicOrder(order)
      });
    }

    order.status = 'COMPLETED';
    order.captureId = verification.captureId;
    order.payerName = verification.payerName;
    order.payerEmail = verification.payerEmail;
    order.paidAt = new Date().toISOString();
    orders.set(order.orderId, order);

    res.json(publicOrder(order));
  } catch (error) {
    next(error);
  }
});

/** Order status / receipt lookup. */
app.get('/api/orders/:orderId', (req, res) => {
  const order = orders.get(req.params.orderId);
  if (!order) return res.status(404).json({ error: 'Order not found.' });
  res.json(publicOrder(order));
});

/* ------------------------------------------------------------------ */
/* Errors                                                              */
/* ------------------------------------------------------------------ */

app.use('/api', (req, res) => {
  res.status(404).json({ error: 'Endpoint not found.' });
});

app.use((error, req, res, next) => { // eslint-disable-line no-unused-vars
  const isPaypal = error instanceof PaypalError;
  const status = isPaypal ? (error.status >= 400 && error.status < 500 ? 400 : 502) : 500;

  console.error(`[${new Date().toISOString()}] ${req.method} ${req.originalUrl} -> ${status}:`, error.message);

  res.status(status).json({
    error: isPaypal
      ? `${error.message}${error.details?.length ? ` (${error.details.join('; ')})` : ''}`
      : 'Something went wrong on the server. Please check the terminal logs and try again.'
  });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log('');
  console.log('  BizMate AI is running');
  console.log(`  → http://localhost:${PORT}`);
  console.log(`  AI:     ${aiConfigured() ? `live (${process.env.AI_MODEL || 'gpt-4o-mini'})` : 'DEMO mode — add OPENAI_API_KEY to .env'}`);
  console.log(`  PayPal: ${paypalConfigured() ? paypalEnv().toUpperCase() : 'DEMO mode — add PAYPAL_CLIENT_ID + PAYPAL_CLIENT_SECRET to .env'}`);
  console.log('');
});
