# BizMate AI

An AI-powered business assistant for small online sellers: generate product descriptions,
draft replies to customer questions, browse a catalogue and take **PayPal Sandbox** payments
that are **verified on the server** before an order is confirmed.

Built with HTML / CSS / JavaScript on the front, Node.js + Express on the back.

| AI description writer | Checkout (server-side price) | Verified receipt |
| --- | --- | --- |
| ![AI writer](artifacts/01-ai-writer.png) | ![Checkout](artifacts/02-checkout.png) | ![Receipt](artifacts/03-receipt.png) |

> Screenshots above are from **demo mode**. With PayPal Sandbox keys the button becomes the
> real PayPal checkout; with an AI key the output is no longer labelled "demo".

---

## 1. What was fixed from the first version

| Problem in the original `index.html` | Fix |
| --- | --- |
| `<script src="https://paypal.com">` — that URL is not the PayPal SDK, so `paypal is not defined` | The SDK is loaded dynamically with a real client id: `https://paypal.com/sdk/js?client-id=…&currency=USD` |
| `<textarea idcustQuery …>` — missing the `id` attribute's quotes, so the JS `getElementById('custQuery')` crashed | Textarea has `id="custQuery"` |
| `fetch('/api/generate-description')` and `/api/reply-query` had no backend | Real Express routes: `/api/ai/description`, `/api/ai/reply` |
| No `package.json` / no dependencies | `express` + `dotenv`, `npm install` |
| Price `'10.00'` hardcoded in the browser — anyone could edit it | The browser sends a **productId**; the server decides the price |
| `actions.order.capture()` in the browser — a fake client could just call it | Order creation **and** capture happen on the server with the secret, then the amount/currency/status are verified |
| `node : The term 'node' is not recognized` | Install Node.js (see step 1 below) |

---

## 2. Run it on your computer

### Step 1 — install Node.js (fixes the `node is not recognized` error)

1. Go to <https://nodejs.org> and download the **LTS** installer for Windows.
2. Run it, click Next/Finish (keep "Add to PATH" ticked).
3. **Close the VS Code terminal and open a new one** (PATH only updates for new terminals).
4. Check it:

```bash
node -v     # should print v20.x or newer
npm -v
```

If it still says "not recognized", restart VS Code, then the PC.

### Step 2 — install the project

```bash
cd path\to\bizmate-ai
npm install
```

### Step 3 — create your config file

```bash
copy .env.example .env      # Windows PowerShell:  Copy-Item .env.example .env
```

The app runs **without any keys** in demo mode. Add keys when you have them (below).

### Step 4 — start the server

```bash
npm start
```

Open <http://localhost:3000>.

> Use `npm run dev` while editing — it restarts automatically on save.

---

## 3. Turn on the real AI

1. Get an API key from an OpenAI-compatible provider
   (Freebuff: **Account → Developer API**; or your own OpenAI key).
2. Put it in `.env`:

```env
OPENAI_API_KEY=sk-...
AI_BASE_URL=https://freebuff.com/api/v1/paid
AI_MODEL=gpt-4o-mini
```

3. Restart the server. The badge in the header changes from **AI: demo mode** to **AI: live**.

Without a key, the app still works and clearly labels its output as *demo output* — never
present demo output to judges as real AI output.

---

## 4. Turn on PayPal Sandbox

1. Sign in at <https://developer.paypal.com/dashboard/applications/sandbox> (a normal
   PayPal account works; Sandbox is free and uses fake money).
2. **Apps & Credentials → Sandbox → Create App**, name it `BizMate AI`.
3. Copy the **Client ID** and **Secret** into `.env`:

```env
PAYPAL_CLIENT_ID=AX...
PAYPAL_CLIENT_SECRET=EL...
PAYPAL_ENV=sandbox
```

4. Restart. The header shows **PayPal: sandbox** and a real PayPal button appears.
5. Test with a **Sandbox Personal** account from *Testing Tools → Sandbox Accounts*
   (the email/password listed there, not your real PayPal login).

Money never moves in sandbox.

### Quick sandbox check (no browser needed)

```bash
node scripts/paypal-check.js
```

It creates a real sandbox order with your credentials and prints an approval link.
Open the link, log in with a **Sandbox Personal** account, click *Pay Now*, then:

```bash
node scripts/paypal-check.js capture <paypalOrderId>
```

`Verification: PASSED` means OAuth, order creation, capture and amount verification
all work against PayPal's real sandbox API.

---

## 5. How the payment flow works

```
Browser                Server                        PayPal
  |  POST /api/orders    |                              |
  |  {productId}  ------>|  price from catalogue        |
  |                      |  create order (secret)  ---->|
  |  paypalOrderId <-----|  <---- order id              |
  |  user approves  ---------------------------------->  |
  |  POST /capture ----->|  capture (secret)      ---->  |
  |                      |  verify status = COMPLETED    |
  |                      |  verify amount + currency     |
  |  order confirmed <---|  only then: status COMPLETED  |
```

Key security points worth explaining in your demo:

- The **client secret never reaches the browser**.
- The **price comes from the server catalogue**, so it can't be edited in DevTools.
- A capture is only accepted if PayPal reports `COMPLETED` **and** the amount/currency match.
- Capturing twice returns the existing order instead of charging again.

### API

| Method | Path | Purpose |
| --- | --- | --- |
| `GET` | `/api/health` | Which integrations are live |
| `GET` | `/api/catalog` | Products + status |
| `GET` | `/api/paypal/config` | Public client id only |
| `POST` | `/api/ai/description` | `{productName, productFeatures, tone, audience}` |
| `POST` | `/api/ai/reply` | `{customerQuery, businessName, tone}` |
| `POST` | `/api/orders` | `{productId, quantity}` → order |
| `POST` | `/api/orders/:id/capture` | Verify payment, confirm order |
| `GET` | `/api/orders/:id` | Order / receipt |

---

## 6. Project structure

```
bizmate-ai/
├── server.js            Express app: routes, rate limit, errors
├── src/
│   ├── ai.js            AI calls + offline fallback
│   ├── paypal.js        OAuth, create/capture order, verification
│   └── orderStore.js    JSON-file order persistence
├── scripts/
│   └── paypal-check.js  Sandbox end-to-end diagnostic
├── docs/
│   └── DEMO-VIDEO.md    Shot-by-shot testing video script
├── data/
│   └── products.js      Server-side catalogue (source of truth for prices)
├── public/
│   ├── index.html       UI
│   ├── style.css        Styling
│   └── app.js           Frontend logic
├── .env.example         Copy to .env and fill in keys
└── package.json
```

Orders are saved to `data/orders.json` (git-ignored), so a restart does not lose them.
That file is for a prototype; swap `src/orderStore.js` for MongoDB/Postgres in production —
the rest of the code only uses `get` / `set`.

---

## 7. Hackathon submission checklist

- [ ] `node -v` works, `npm install` and `npm start` succeed on a clean machine
- [ ] `.env` is **not** committed (`git status` should not list it)
- [ ] Screenshot of a completed PayPal Sandbox payment + the receipt section
- [ ] README pushed to GitHub (this file)
- [ ] 3–5 minute demo script: AI description → AI reply → buy → PayPal sandbox → confirmed order
      (shot list ready in [docs/DEMO-VIDEO.md](docs/DEMO-VIDEO.md))
- [ ] Say clearly which parts are demo mode and which need keys

### 3-minute demo script

1. **Problem** (20s): small sellers lose hours on listings and support.
2. **AI writer** (40s): type "bamboo bottle" + features, generate, copy.
3. **Support reply** (30s): paste "when will I get my refund?", show the draft.
4. **Catalogue + checkout** (60s): Buy now → PayPal Sandbox login → pay.
5. **Verification** (30s): show the receipt with order id, capture id, amount, status; then
   open `server.js` on screen to show the price comes from the server, not the browser.

---

## 8. Known limitations / future scope

- Orders in a JSON file (fine for one server; use MongoDB/Postgres for production).
- No user accounts or admin panel yet; the catalogue is hardcoded.
- No inventory, analytics or order emails.
- AI output must be reviewed before it is sent to real customers.
